self.__BUILD_MANIFEST = {
  "/404": [
    "./static/chunks/9d2c7b4a0d7443aa.js"
  ],
  "/500": [
    "./static/chunks/f85e0af9b75eefdf.js"
  ],
  "/_error": [
    "./static/chunks/99eb158b762a6fcf.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/404",
    "/500",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()