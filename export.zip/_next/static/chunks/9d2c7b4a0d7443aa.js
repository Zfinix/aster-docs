__turbopack_load_page_chunks__("/404", [
  "static/chunks/67ca4d2205f96767.js",
  "static/chunks/0768df1ae6a31175.js",
  "static/chunks/b93312a88edc6c59.js",
  "static/chunks/8c4ff94e1129beef.js",
  "static/chunks/50fd38d056920d32.js",
  "static/chunks/turbopack-5e68a6778cc0e4b4.js"
])
